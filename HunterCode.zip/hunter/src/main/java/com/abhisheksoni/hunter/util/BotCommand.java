package com.abhisheksoni.hunter.util;

public enum BotCommand {
    START,
    STOP;
}
