package com.abhisheksoni.hunter.exception;

public class HunterException extends RuntimeException {
    public HunterException(String message) {
        super(message);
    }
}
