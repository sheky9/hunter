package com.abhisheksoni.hunter.util;

public enum HunterEvent {
    KEYS,
    KEYS_ADD,
    SUBS,
    SUBS_ADD,
    INFO,
    COLLAB,
    HELP,
    UNKNOWN
}
