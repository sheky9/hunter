package com.abhisheksoni.hunter.util;

public class  Constants {
    public static final String BOT_NAME = "Hunter";
    public static final String DISCORD_BOT_TOKEN = "ODk2MzA4NDY2ODI0NjYzMDQw.YWFOTw.5KsT-kIj_hhBnAJILfRC6kfubwA";
    public static final String BOT_TRIGGER_NAME = "hunter";
}
